﻿namespace Inss.Gds.Host.Model;

public abstract class BaseModel
{
    public string Id { get; init; } = string.Empty;
    
    public string NextPage { get; init; } = string.Empty;
    
    public string PreviousPage { get; init; } = string.Empty;
    
    public string CurrentPage { get; init; } = string.Empty;
    
    public Error[] Errors { get; set; } = [];
}

public sealed class Error
{
    public string PropertyName { get; init; } = string.Empty;
    
    public string Message { get; init; } = string.Empty;
}

public sealed class AnswerTextQuestionModel : BaseModel
{
    public string QuestionText { get; init; } = string.Empty;
    
    public string AnswerText { get; init; } = string.Empty;
    
    public string BackButtonText { get; init; } = "Back";
    
    public string ContinueButtonText { get; init; } = "Continue";
}