﻿using Inss.Gds.Host.Model;
using Inss.Gds.Host.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Inss.Gds.Host.Components;

public abstract class BasePageModel<T> : PageModel where T : BaseModel
{
    private readonly IModelService _modelService;

    protected BasePageModel(IModelService modelService)
    {
        _modelService = modelService;
    }
    
    protected abstract string PageId { get; }
    
    [BindProperty]
    public T Input { get; set; } = null!;
    
    public async Task OnGetAsync()
    {
        Input = await _modelService.LoadAsync<T>(PageId);

        foreach (var error in Input.Errors)
        {
            ModelState.AddModelError(error.PropertyName, error.Message);
        }
    }

    public async Task<IActionResult> OnPostAsync()
    {
        return await _modelService.ProcessAsync(Input);
    }
}