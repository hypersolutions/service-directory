﻿using Inss.Gds.Host.Model;
using Inss.Gds.Host.Services;

namespace Inss.Gds.Host.Components.AnswerTextQuestion;

public class Razor : BasePageModel<AnswerTextQuestionModel>
{
    public Razor(IModelService modelService) : base(modelService)
    {
    }
    
    protected override string PageId => "";
}