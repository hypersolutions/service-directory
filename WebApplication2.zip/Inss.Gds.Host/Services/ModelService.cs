﻿using Inss.Gds.Host.Model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Inss.Gds.Host.Services;

public interface IModelService
{
    Task<T> LoadAsync<T>(string id) where T : BaseModel;
    
    Task<IActionResult> ProcessAsync<T>(T model) where T : BaseModel;
}
public class ModelService : IModelService 
{
    public async Task<T> LoadAsync<T>(string id) where T : BaseModel
    {
        await Task.Delay(10);
        
        var model = await ModelCache.RetrieveAsync<T>(id);
        return model ?? (T)(BaseModel)new AnswerTextQuestionModel
        {
            Id = "55491338-738e-40a4-9745-57c3593f6f5b",
            QuestionText = "What is your first name?",
            NextPage = "/",
            PreviousPage = "/",
            CurrentPage = "/example"
        };
    }
    public async Task<IActionResult> ProcessAsync<T>(T model)  where T : BaseModel
    {
        // TODO: Validate and return

        await Task.Delay(10);
        
        var hasErrors = true;
        
        if (hasErrors)
        {
            //var m = await LoadAsync<T>(model.Id);
            model.Errors = [new Error { PropertyName = "AnswerText", Message = "Oops, fill me in!" }];
            await ModelCache.StashAsync(model);
            return new RedirectToPageResult(model.CurrentPage);
        }
        
        return new RedirectToPageResult(model.NextPage);
    }
}

public class ModelCache
{
    private static readonly Dictionary<string, BaseModel> _cache = new();

    public static async Task<T?> RetrieveAsync<T>(string id) where T : BaseModel
    {
        await Task.Delay(10);
        
        if (_cache.TryGetValue(id, out var model))
        {
            return model as T;
        }

        return null;
    }
    
    public static async Task StashAsync<T>(T model) where T : BaseModel
    {
        await Task.Delay(10);
        _cache[model.Id] = model;
    }
}