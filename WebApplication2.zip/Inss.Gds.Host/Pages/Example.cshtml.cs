﻿using Inss.Gds.Host.Components;
using Inss.Gds.Host.Model;
using Inss.Gds.Host.Services;

namespace Inss.Gds.Host.Pages;

public class Example : BasePageModel<AnswerTextQuestionModel>
{
    public Example(IModelService modelService) : base(modelService)
    {
    }

    protected override string PageId => "55491338-738e-40a4-9745-57c3593f6f5b";
}