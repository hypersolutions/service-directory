﻿namespace RazorDemo.FormModel;

public abstract class Question
{
    public string Name { get; init; } = string.Empty;
    
    public string ClassName { get; init; } = string.Empty;
    
    public string QuestionText { get; init; } =  string.Empty;
    
    public string? PreviousQuestion { get; set; }
    
    public string? NextQuestion { get; init; }
}