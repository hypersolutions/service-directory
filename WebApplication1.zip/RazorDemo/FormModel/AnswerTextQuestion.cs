﻿using System.ComponentModel.DataAnnotations;

namespace RazorDemo.FormModel;

public sealed class AnswerTextQuestion : Question
{
    public string AnswerText { get; set; } =   string.Empty;

    public ValidationAttribute[] ValidationRules { get; init; } = [];
}