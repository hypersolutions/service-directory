﻿namespace RazorDemo.FormModel;

public sealed class Page
{
    public string Name { get; init; } = string.Empty;
    
    public List<Question> Questions { get; init; } = [];
}