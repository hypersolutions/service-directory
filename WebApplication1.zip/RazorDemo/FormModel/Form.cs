﻿using RazorDemo.FormModel.Services;

namespace RazorDemo.FormModel;

public sealed class Form
{
    public Form()
    {
        FormService = new DemoFormService(this);
    }
    
    public int Id { get; init; }
    
    public string Name { get; init; } = string.Empty;

    public List<Page> Pages { get; init; } = [];

    public FormService FormService { get; }
}