﻿namespace RazorDemo.FormModel.Services;

public abstract class FormService
{
    public abstract Task UpdateAsync(string questionId);
}