﻿namespace RazorDemo.FormModel.Services;

public sealed class DemoFormService : FormService
{
    private readonly Form _form;

    public DemoFormService(Form form)
    {
        _form = form;
    }
    
    public override async Task UpdateAsync(string questionId)
    {
        // Load the data for the form Id to update
        Console.WriteLine($"Loading data for {_form.Id} and finding question {questionId}");
        
        // Find the question to update on the model return from the db and update its data then save
        
        await Task.Delay(10);
    }
}