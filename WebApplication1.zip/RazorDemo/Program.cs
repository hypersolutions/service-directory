using GovUk.Frontend.AspNetCore;
using RazorDemo;
using RazorDemo.Engine;


var formGen = new FormGenerator();
var form = formGen.GetForm();

//var formCodeGen = new FormCodeGenerator();
//formCodeGen.Generate(form);


var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddRazorPages();//.AddRazorRuntimeCompilation();;

// Add GOV.UK Frontend services
builder.Services.AddGovUkFrontend();

builder.Services.AddTransient(form.FormService.GetType(), _ => form.FormService);
//builder.Services.AddTransient<DemoFormService>(_ => new DemoFormService(form));

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();

app.UseRouting();

app.UseAuthorization();

app.MapStaticAssets();
app.MapRazorPages()
    .WithStaticAssets();

app.Run();
