﻿using System.ComponentModel.DataAnnotations;
using RazorDemo.FormModel;

namespace RazorDemo;

public class FormGenerator
{
    public Form GetForm()
    {
        // TODO: Serialize form json

        var q1 = new AnswerTextQuestion
        {
            QuestionText = "What is your first name?", 
            Name = "first-name", 
            ClassName = "FirstName", 
            NextQuestion = "contact-details/personal-details/last-name",
            ValidationRules = [new RequiredAttribute{ErrorMessage = "Answer is required."}]
        };
        
        var q2 = new AnswerTextQuestion
        {
            QuestionText = "What is your last name?", 
            Name = "last-name", 
            ClassName = "LastName", 
            NextQuestion = "contact-details/phone-details/mobile-number", 
            PreviousQuestion = "contact-details/personal-details/first-name"
        };
        
        var p1 = new Page { Name = "personal-details" };
        p1.Questions.Add(q1);
        p1.Questions.Add(q2);
        
        var q3 = new AnswerTextQuestion
        {
            QuestionText = "What is your mobile number?", 
            Name = "mobile-number", 
            ClassName = "MobileNumber", 
            NextQuestion = "contact-details/phone-details/home-number", 
            PreviousQuestion = "contact-details/personal-details/last-name"
        };
        
        var q4 = new AnswerTextQuestion
        {
            QuestionText = "What is your home number?", 
            Name = "home-number", 
            ClassName = "HomeNumber", 
            PreviousQuestion = "contact-details/phone-details/mobile-number"
        };
        
        var p2 = new Page { Name = "phone-details" };
        p2.Questions.Add(q3);
        p2.Questions.Add(q4);
        
        var form = new Form { Name = "contact-details", Id = 101 }; // The Id in a db (or somewhere that represents the data for a user that needs to be updated
        form.Pages.Add(p1);
        form.Pages.Add(p2);

        return form;
    }
}