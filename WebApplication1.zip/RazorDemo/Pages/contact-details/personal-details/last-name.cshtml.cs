
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace RazorDemo.Pages;

public class LastName : PageModel
{
    private readonly RazorDemo.FormModel.Services.DemoFormService _formService;
    private readonly string _questionId = "last-name"; // The identifier of some form

    public LastName(RazorDemo.FormModel.Services.DemoFormService formService)
    {
        _formService = formService;
    }

    public string QuestionText { get; set; } = string.Empty;

    [BindProperty]
    
    public string AnswerText { get; set; } = string.Empty;

    public string? PreviousQuestion { get; set; }

    public void OnGet()
    {
        QuestionText = "What is your last name?";
        PreviousQuestion = "contact-details/personal-details/first-name";
    }

    public async Task<IActionResult> OnPostAsync()
    {
        if (!ModelState.IsValid)
        {
            QuestionText = "What is your last name?";
            PreviousQuestion = "contact-details/personal-details/first-name";
            return Page();
        }
        
        await _formService.UpdateAsync(_questionId);
        return RedirectToPage("/contact-details/phone-details/mobile-number");
    }
}
