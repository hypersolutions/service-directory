
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace RazorDemo.Pages;

public class FirstName : PageModel
{
    private readonly RazorDemo.FormModel.Services.DemoFormService _formService;
    private readonly string _questionId = "first-name"; // The identifier of some form

    public FirstName(RazorDemo.FormModel.Services.DemoFormService formService)
    {
        _formService = formService;
    }

    public string QuestionText { get; set; } = string.Empty;

    [BindProperty]
    [System.ComponentModel.DataAnnotations.RequiredAttribute(ErrorMessage="Answer is required.")]
    public string AnswerText { get; set; } = string.Empty;

    public string? PreviousQuestion { get; set; }

    public void OnGet()
    {
        QuestionText = "What is your first name?";
        PreviousQuestion = "";
    }

    public async Task<IActionResult> OnPostAsync()
    {
        if (!ModelState.IsValid)
        {
            QuestionText = "What is your first name?";
            PreviousQuestion = "";
            return Page();
        }
        
        await _formService.UpdateAsync(_questionId);
        return RedirectToPage("/contact-details/personal-details/last-name");
    }
}
