
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace RazorDemo.Pages;

public class HomeNumber : PageModel
{
    private readonly RazorDemo.FormModel.Services.DemoFormService _formService;
    private readonly string _questionId = "home-number"; // The identifier of some form

    public HomeNumber(RazorDemo.FormModel.Services.DemoFormService formService)
    {
        _formService = formService;
    }

    public string QuestionText { get; set; } = string.Empty;

    [BindProperty]
    
    public string AnswerText { get; set; } = string.Empty;

    public string? PreviousQuestion { get; set; }

    public void OnGet()
    {
        QuestionText = "What is your home number?";
        PreviousQuestion = "contact-details/phone-details/mobile-number";
    }

    public async Task<IActionResult> OnPostAsync()
    {
        if (!ModelState.IsValid)
        {
            QuestionText = "What is your home number?";
            PreviousQuestion = "contact-details/phone-details/mobile-number";
            return Page();
        }
        
        await _formService.UpdateAsync(_questionId);
        return RedirectToPage("/");
    }
}
