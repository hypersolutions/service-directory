
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace RazorDemo.Pages;

public class MobileNumber : PageModel
{
    private readonly RazorDemo.FormModel.Services.DemoFormService _formService;
    private readonly string _questionId = "mobile-number"; // The identifier of some form

    public MobileNumber(RazorDemo.FormModel.Services.DemoFormService formService)
    {
        _formService = formService;
    }

    public string QuestionText { get; set; } = string.Empty;

    [BindProperty]
    
    public string AnswerText { get; set; } = string.Empty;

    public string? PreviousQuestion { get; set; }

    public void OnGet()
    {
        QuestionText = "What is your mobile number?";
        PreviousQuestion = "contact-details/personal-details/last-name";
    }

    public async Task<IActionResult> OnPostAsync()
    {
        if (!ModelState.IsValid)
        {
            QuestionText = "What is your mobile number?";
            PreviousQuestion = "contact-details/personal-details/last-name";
            return Page();
        }
        
        await _formService.UpdateAsync(_questionId);
        return RedirectToPage("/contact-details/phone-details/home-number");
    }
}
