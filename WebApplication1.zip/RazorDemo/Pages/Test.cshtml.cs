﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace RazorDemo.Pages;

public class Test : PageModel
{
    public void OnGet()
    {
        
        this.Content(System.IO.File.ReadAllText("./Html/File.html"));
    }
}