﻿using RazorDemo.Engine.Extensions;
using RazorDemo.FormModel;

namespace RazorDemo.Engine;

public class FormCodeGenerator
{
    public void Generate(Form form)
    {
        // Create the dir for the form under pages
        var formDir = Path.Combine(Directory.GetCurrentDirectory(), "Pages", form.Name);
        Directory.CreateDirectory(formDir);

        foreach (var page in form.Pages)
        {
            // Create the page dir under the form page
            var pageDir = Path.Combine(formDir, page.Name);
            Directory.CreateDirectory(pageDir);

            foreach (var question in page.Questions)
            {
                // Create the razor file
                var razorContent = question.GenerateRazor(form);
                var questionPath = Path.Combine(pageDir, $"{question.Name}.cshtml");
                File.WriteAllText(questionPath, razorContent);
                
                // Create the razor model page
                var codeModelContent = question.GenerateCode(form);
                questionPath = Path.Combine(pageDir, $"{question.Name}.cshtml.cs");
                File.WriteAllText(questionPath, codeModelContent);
            }
        }
    }
}