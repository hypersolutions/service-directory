﻿using RazorDemo.FormModel;

namespace RazorDemo.Engine.Extensions;

public static class QuestionExtensions
{
    public static string GenerateCode(this Question question, Form form)
    {
        return question switch
        {
            AnswerTextQuestion atq => GenerateCode(atq, form),
            _ => throw new NotImplementedException()
        };
    }
    
    public static string GenerateRazor(this Question question, Form form)
    {
        return question switch
        {
            AnswerTextQuestion atq => GenerateRazor(atq, form),
            _ => throw new NotImplementedException()
        };
    }

    private static string GenerateCode(AnswerTextQuestion question, Form form)
    {
        var validationAttributes = question.ValidationRules.GenerateCode();
        
        // TODO: Turn this into a syntax tree?
        
        var code = $@"
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace RazorDemo.Pages;

public class {question.ClassName} : PageModel
{{
    private readonly {form.FormService.GetType().FullName} _formService;
    private readonly string _questionId = ""{question.Name}""; // The identifier of some form

    public {question.ClassName}({form.FormService.GetType().FullName} formService)
    {{
        _formService = formService;
    }}

    public string QuestionText {{ get; set; }} = string.Empty;

    [BindProperty]
    {validationAttributes}
    public string AnswerText {{ get; set; }} = string.Empty;

    public string? PreviousQuestion {{ get; set; }}

    public void OnGet()
    {{
        QuestionText = ""{question.QuestionText}"";
        PreviousQuestion = ""{question.PreviousQuestion}"";
    }}

    public async Task<IActionResult> OnPostAsync()
    {{
        if (!ModelState.IsValid)
        {{
            QuestionText = ""{question.QuestionText}"";
            PreviousQuestion = ""{question.PreviousQuestion}"";
            return Page();
        }}
        
        await _formService.UpdateAsync(_questionId);
        return RedirectToPage(""/{question.NextQuestion}"");
    }}
}}
";

        return code;
    }

    private static string GenerateRazor(this AnswerTextQuestion question, Form form)
    {
        var razorContent = $@"
@page
@model {question.ClassName}

<form method=""post"">
    <div class=""govuk-form-group govuk-form-group--error"">
        <h1 class=""govuk-label-wrapper"">
            <label class=""govuk-label govuk-label--l"" for=""question"">
                @Model.QuestionText
            </label>
        </h1>
        <p id=""{question.Name}-error"" class=""govuk-error-message"">
            <span class=""govuk-visually-hidden"" asp-validation-for=""@Model.AnswerText""></span>
        </p>
        <input class=""govuk-input"" id=""question"" asp-for=""@Model.AnswerText"" type=""text"">
        @if (Model.PreviousQuestion is not null)
        {{
            <a href=""~/@Model.PreviousQuestion"" class=""govuk-back-link"">Back</a>
        }}
        <button type=""submit"" class=""govuk-button"" data-module=""govuk-button"">
            Save and continue
        </button>
    </div>
</form>
";
        return razorContent;
    }
}