﻿using System.ComponentModel.DataAnnotations;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;

namespace RazorDemo.Engine.Extensions;

public static class ValidationAttributeExtensions
{
    public static string GenerateCode(this ValidationAttribute[] attributes)
    {
        if (attributes.Length == 0) return string.Empty;
        
        var list = new List<AttributeSyntax>();
        
        foreach (var attribute in attributes)
        {
            var attributeSyntax = attribute switch
            {
                RequiredAttribute requiredAttribute => GenerateCode(requiredAttribute),
                _ => throw new NotImplementedException()
            };
            
            list.Add(attributeSyntax);
        }
        var attributeList = SyntaxFactory.AttributeList(SyntaxFactory.SeparatedList(list));
        
        return attributeList.ToFullString();
    }

    private static AttributeSyntax GenerateCode(RequiredAttribute attribute)
    {
        var attributeSyntax = SyntaxFactory.Attribute(
                SyntaxFactory.IdentifierName(attribute.GetType().FullName!))
            .WithArgumentList(
                SyntaxFactory.AttributeArgumentList(
                    SyntaxFactory.SingletonSeparatedList(
                        SyntaxFactory.AttributeArgument(
                            SyntaxFactory.NameEquals("ErrorMessage"),
                            null,
                            SyntaxFactory.LiteralExpression(
                                SyntaxKind.StringLiteralExpression,
                                SyntaxFactory.Literal(attribute.ErrorMessage!)
                            )
                        )
                    )
                )
            );
        
        return attributeSyntax;
    }
}