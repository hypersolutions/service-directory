using GovUk.Frontend.AspNetCore;
using WebApplication4.Pages;

var builder = WebApplication.CreateBuilder(args);

//builder.Services.AddSingleton<TestHelper>();

// Add services to the container.
builder.Services.AddRazorPages().AddRazorPagesOptions(options =>
{
    //var provider = builder.Services.BuildServiceProvider();
    //var helper = new TestHelper();// provider.GetRequiredService<TestHelper>();
    //options.Conventions.AddPageRoute("/Test", () => helper.GetNext());
});
builder.Services.AddGovUkFrontend();

builder.Services.AddTransient<IAccountService, AccountService>();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();

app.UseRouting();

app.UseAuthorization();

app.MapStaticAssets();
app.MapRazorPages()
    .WithStaticAssets();
app.UseGovUkFrontend();

app.Run();