﻿using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Mvc.ViewFeatures;
using Microsoft.AspNetCore.Razor.TagHelpers;

namespace WebApplication4.TagHelpers;

[HtmlTargetElement("inss-question", Attributes = ForAttributeName)]
public class QuestionTagHelper : TagHelper
{
    private const string ForAttributeName = "asp-for";

    [HtmlAttributeName(ForAttributeName)]
    public ModelExpression For { get; set; }

    [HtmlAttributeNotBound]
    [ViewContext]
    public required ViewContext ViewContext { get; set; }
    
    public string Question { get; set; } = string.Empty;
    
    public string Hint { get; set; } = string.Empty;
    
    public override void Process(TagHelperContext context, TagHelperOutput output)
    {
        output.TagName = "div";
        output.TagMode = TagMode.StartTagAndEndTag;

        var errorBlock = string.Empty;
        
        if (ViewContext.ViewData.ModelState.ErrorCount > 0 &&
            ViewContext.ViewData.ModelState.TryGetValue(For.Name, out var value) &&
            value.Errors.Count > 0)
        {
            var error = value.Errors.First();
            errorBlock = $@"<p class=""govuk-error-message""><span class=""govuk-visually-hidden"">Error:</span>{error.ErrorMessage}</p>";
        }
        
        var input = $@"
        <div class=""govuk-form-group"">
  <h1 class=""govuk-label-wrapper"">
    <label class=""govuk-label govuk-label--l"" for=""{For.Name}"">
      {Question}
    </label>
  </h1>
  <div id=""AccountNumber-hint"" class=""govuk-hint"">
    {Hint}
  </div>
    {errorBlock}
  <input class=""govuk-input govuk-input--width-10"" id=""{For.Name}"" name=""{For.Name}"" type=""text"" spellcheck=""false"" aria-describedby=""{For.Name}-hint"" inputmode=""text"">
</div>
";
        output.Content.SetHtmlContent(input);
    }
}

[HtmlTargetElement("inss-form")]
public class FormTagHelper : TagHelper
{
    // private const string ForAttributeName = "asp-for";
    //
    // [HtmlAttributeName(ForAttributeName)]
    // public ModelExpression For { get; set; }

    // This property will capture the nested Razor content
    [HtmlAttributeNotBound]
    [ViewContext]
    public required ViewContext ViewContext { get; set; }

    public string SubmitText { get; set; } = "Save and continue";
    
    public string BackText { get; set; } = "Back";
    
    public string BackUrl { get; set; } = "/";
    
    public override async Task ProcessAsync(TagHelperContext context, TagHelperOutput output)
    {
        // Get the inner content (can contain Razor markup)
        var childContent = await output.GetChildContentAsync();

        output.TagName = "form";
        output.Attributes.SetAttribute("method", "post");

        /*
         <button type="submit" class="govuk-button" data-module="govuk-button" data-govuk-button-init="">
  Save and continue
</button>
         */
        output.Content.SetHtmlContent($@"
            {childContent.GetContent()}
            <a href=""{BackUrl}"" class=""govuk-back-link"">{BackText}</a>
            <button type=""submit"" class=""govuk-button"">{SubmitText}</button>
<input name=""__RequestVerificationToken"" type=""hidden"" value=""CfDJ8EOCmCpHu5lNmYmXMN5TaNB1wWRAb3pAu3panBiduSmC8m21NgOYCbk_81836C9bCc0Due3NOZWSqkjUkZCOGrRs6rcBkKuJT6aUAhzG_csWK37UbosSAJGLMO28fTLJBPd-2Yj3C1WbIcUDZWAGRMA"">
            ");
    }
}
