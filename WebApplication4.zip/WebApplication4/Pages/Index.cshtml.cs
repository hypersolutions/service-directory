using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WebApplication4.Pages;

public class IndexModel : PageModel
{
    private readonly IAccountService _accountService;

    public IndexModel(IAccountService accountService)
    {
        _accountService = accountService;
    }
    
    [BindProperty]
    public required Account Account { get; set; }

    public async Task OnGetAsync()
    {
        Account = await _accountService.GetAsync();
    }

    public async Task<IActionResult> OnPostAsync()
    {
        if (!ModelState.IsValid)
        {
            return Page();
        }

        await _accountService.SaveAsync(Account);

        return RedirectToPage("/"); // TODO:
    }
}

public sealed class Account
{
    [RegularExpression("^[0-9]{8}$", ErrorMessage = "The account number must be 8 numbers.")]
    public string Number { get; set; } = string.Empty;

    [RegularExpression("^[0-9]{2}-[0-9]{2}-[0-9]{2}$", ErrorMessage = "The sort code must be in the format 11-22-33")]
    public string SortCode { get; set; } = string.Empty;
}

public interface IAccountService
{
    Task<Account> GetAsync();
    Task SaveAsync(Account account);
}

public sealed class AccountService : IAccountService
{
    public Task<Account> GetAsync()
    {
        // TODO: Resolve for user
        return Task.FromResult(new Account());
    }

    public Task SaveAsync(Account account)
    {
        return Task.CompletedTask;
    }
}

