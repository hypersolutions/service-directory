﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WebApplication4.Pages;

public class Test : PageModel
{
    //public string Route { get; set; } = "/test-route/demo";
    public void OnGet()
    {
        
    }
}

public sealed class TestHelper
{
    private static int _counter = 1;

    public string GetNext()
    {
        return $"my-route{++_counter}";
    }
}