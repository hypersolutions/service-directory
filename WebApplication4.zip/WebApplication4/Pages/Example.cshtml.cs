﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WebApplication4.Pages;

public class Example : PageModel
{
    public void OnGet()
    {
        
    }
    
    public IActionResult OnPost()
    {
        return Page();
    }
}