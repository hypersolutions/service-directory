﻿using ConsoleApp1;

var page1 = new PageModel { Id = "Page1", Question = new DoBModel { Id = "Q1" }, Nav = new Navigation{ Controller = "Dob" } };
        
var page2 = new PageModel { Id = "Page2", Question = new AddressModel { Id = "Q2" }, Nav = new Navigation{ Controller = "Address" } };
        
var page3 = new PageModel { Id = "Page3", Question = new PhoneModel { Id = "Q3" }, Nav = new Navigation{ Controller = "Phone" } };

var section1 = new SectionModel { Name = "Contact", Pages = [page1, page2, page3] };

var form = new FormModel { Sections = [section1] };

var sm = new StateMachine();

var nav = sm.Transision(form);
Console.WriteLine($"{nav.Controller}: {nav.Action}");

var dob = (DoBModel)page1.Question;
dob.Dob = DateOnly.Parse("2019-01-02");

nav = sm.Transision(form);
Console.WriteLine($"{nav.Controller}: {nav.Action}");
