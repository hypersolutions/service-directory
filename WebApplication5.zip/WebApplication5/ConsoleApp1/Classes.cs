﻿namespace ConsoleApp1;

public class Tester
{
    public void Do()
    {
        
        
        
    }
}

public class StateMachine
{
    private string? _currentPageId;

    public StateMachine() // Inject the IServiceProvider and find resolver for the question 
    {
        // TODO: Create a fallback which just gets the next page in the section or handles the summary or back to the task list
    }
    
    public Navigation Transision(FormModel form) //, PageModel? page)
    {
        PageModel? nextPage = null;
        
        if (_currentPageId is null) // && page is null)
        {
            nextPage = form.Sections.First().Pages.First();
        }
        else //if (_currentPageId is not null)
        {
            // Find the current page for the Id
            var currentPage = form.FindPage(_currentPageId)!;

            if (currentPage.Question is DoBModel dob)
            {
                if (dob.Dob > DateOnly.Parse("2020-01-01"))
                {
                    nextPage = form.FindPage("Page3");
                }
                else
                {
                    nextPage = form.FindPage("Page2");
                }
            }
        }
        
        _currentPageId = nextPage!.Id; // TODO: Should not be null
        return nextPage.Nav;
    }
}

public interface IStateResolver<TQuestion> where TQuestion : QuestionModel
{
    PageModel Resolve(FormModel form, TQuestion question);
}

public sealed class DobStateResolver : IStateResolver<DoBModel>
{
    public PageModel Resolve(FormModel form, DoBModel question)
    {
        // If dob model is used across various pages then we can check the Id and handle the state transision accordingly
        PageModel nextPage;
        
        if (question.Dob > DateOnly.Parse("2020-01-01"))
        {
            nextPage = form.FindPage("Page3");
        }
        else
        {
            nextPage = form.FindPage("Page2");
        }

        return nextPage;
    }
}

public sealed class FormModel
{
    public SectionModel[] Sections { get; init; }

    public PageModel? FindPage(string pageId)
    {
        foreach (var section in Sections)
        {
            foreach (var page in section.Pages)
            {
                if (page.Id == pageId) return page;
            }
        }

        return null;
    }
}

public sealed class SectionModel
{
    public string Name { get; init; }
    public PageModel[] Pages { get; init; }
}

public sealed class PageModel
{
    public string Id { get; init; }
    public string Name { get; init; }
    public QuestionModel Question { get; init; }
    public Navigation Nav { get; init; }
}

public abstract class QuestionModel
{
    public string Id { get; init; }
}

public sealed class AddressModel : QuestionModel
{
    public string Line1 { get; set; }
    public string Line2 { get; set; }
    public string Postcode { get; set; }
}

public sealed class DoBModel : QuestionModel
{
    public DateOnly Dob { get; set; }
}

public sealed class PhoneModel : QuestionModel
{
    public string Number { get; set; }
}

public sealed class Navigation
{
    public string Controller { get; init; }
    public string Action { get; init; } = "Index";
}