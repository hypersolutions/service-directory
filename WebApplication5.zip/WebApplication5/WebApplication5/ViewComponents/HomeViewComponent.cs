﻿using Microsoft.AspNetCore.Mvc;
using WebApplication5.Models;

namespace WebApplication5.ViewComponents;

public class HomeViewComponent : ViewComponent
{
    private readonly ILogger<HomeViewComponent> _logger;

    public HomeViewComponent(ILogger<HomeViewComponent> logger)
    {
        _logger = logger;
    }
    
    public async Task<IViewComponentResult> InvokeAsync()
    {
        // Simulate async data fetching
        await Task.Delay(10);
        return View(new HomeModel()); // Pass data to the view
    }
}