﻿using Microsoft.AspNetCore.Mvc;

namespace WebApplication5.ViewComponents;

public class LatestArticlesViewComponent : ViewComponent
{
    // Simulated data source
    private readonly List<string> _articles = new()
    {
        "ASP.NET Core View Components",
        "Dependency Injection in .NET",
        "Entity Framework Core Tips",
        "C# 12 New Features"
    };

    // This method is called when the component is invoked
    public async Task<IViewComponentResult> InvokeAsync(int count)
    {
        // Simulate async data fetching
        var latest = await Task.Run(() => _articles.GetRange(0, Math.Min(count, _articles.Count)));
        return View(latest); // Pass data to the view
    }
}