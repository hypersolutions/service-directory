﻿namespace WebApplication5;

public class Tester
{
    public void Do()
    {
        var page1 = new PageModel { Id = "Page1", Question = new DoBModel(), Nav = new Navigation{ Controller = "Dob" } };
        
        var page2 = new PageModel { Id = "Page2", Question = new AddressModel(), Nav = new Navigation{ Controller = "Address" } };
        
        var page3 = new PageModel { Id = "Page3", Question = new PhoneModel(), Nav = new Navigation{ Controller = "Phone" } };

        var section1 = new SectionModel { Name = "Contact", Pages = [page1, page2, page3] };
        var form = new FormModel { Sections = [section1] };
        
        
    }
}

public class StateMachine
{
    private string? _currentPageId;
    
    public Navigation Todo(FormModel form, PageModel? page)
    {
        PageModel? nextPage = null;
        
        if (_currentPageId is null && page is null)
        {
            nextPage = form.Sections.First().Pages.First();
        }
        else if (_currentPageId is not null)
        {
            // Find the current page for the Id
            var currentPage = form.FindPage(_currentPageId)!;

            if (currentPage.Question is DoBModel dob)
            {
                if (dob.Dob > DateOnly.Parse("2020-01-01"))
                {
                    nextPage = form.FindPage("Page3");
                }
                else
                {
                    nextPage = form.FindPage("Page2");
                }
            }
        }
        
        _currentPageId = nextPage!.Id; // TODO: Should not be null
        return nextPage.Nav;
    }
}

public sealed class FormModel
{
    public SectionModel[] Sections { get; init; }

    public PageModel? FindPage(string pageId)
    {
        foreach (var section in Sections)
        {
            foreach (var page in section.Pages)
            {
                if (page.Id == pageId) return page;
            }
        }

        return null;
    }
}

public sealed class SectionModel
{
    public string Name { get; init; }
    public PageModel[] Pages { get; init; }
}

public sealed class PageModel
{
    public string Id { get; init; }
    public string Name { get; init; }
    public QuestionModel Question { get; init; }
    public Navigation Nav { get; init; }
}

public abstract class QuestionModel
{
    
}

public sealed class AddressModel : QuestionModel
{
    public string Line1 { get; init; }
    public string Line2 { get; init; }
    public string Postcode { get; init; }
}

public sealed class DoBModel : QuestionModel
{
    public DateOnly Dob { get; init; }
}

public sealed class PhoneModel : QuestionModel
{
    public string Number { get; init; }
}

public sealed class Navigation
{
    public string Controller { get; init; }
    public string Action { get; init; } = "Index";
}