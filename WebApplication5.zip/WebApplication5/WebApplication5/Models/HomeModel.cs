﻿using System.ComponentModel.DataAnnotations;

namespace WebApplication5.Models;

public class HomeModel
{
    [Required]
    public string Text { get; set; }
}